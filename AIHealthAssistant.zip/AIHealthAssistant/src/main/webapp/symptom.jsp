<!DOCTYPE html>
<html>
<head>

<title>Symptom Analyzer</title>

<link rel="stylesheet" href="css/style.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="js/app.js"></script>
</head>

<body class="container">

<h2>Symptom Analyzer</h2>

<textarea 
    id="symptoms" 
    placeholder="Describe your symptoms"
    class="form-control"
    rows="1"></textarea>

<input type="number"
    id="age"
    placeholder="Your age"
    class="form-control mt-3">

<button onclick="analyzeSymptoms()"
    class="btn btn-primary mt-3">
    Analyze
</button>

<div id="result" class="result-box"></div>

</body>
</html>

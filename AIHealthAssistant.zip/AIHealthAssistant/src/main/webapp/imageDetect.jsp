<!DOCTYPE html>
<html>
<head>

<title>Skin Disease Detection</title>

<link rel="stylesheet" href="css/style.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="js/app.js"></script>

</head>

<body class="container">

<h2>Upload Skin Image</h2>

<input type="file" id="imageFile" class="form-control">

<button onclick="uploadImage()" class="btn btn-success mt-3">
Detect
</button>

<div id="imageResult" class="result-box"></div>

</body>
</html>
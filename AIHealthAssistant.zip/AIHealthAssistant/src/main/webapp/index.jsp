<!DOCTYPE html>
<html>
<head>

<title>AI Health Assistant</title>

<link rel="stylesheet" href="css/style.css">

<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="js/app.js"></script>

</head>

<body class="container">

<h1 class="title">AI Health Assistant</h1>

<div class="menu">

<a href="symptom.jsp" class="btn btn-primary">Symptom Analyzer</a>

<a href="imageDetect.jsp" class="btn btn-success">Skin Image Detection</a>

<a href="chatbot.jsp" class="btn btn-info">Health Chatbot</a>

</div>

</body>
</html>
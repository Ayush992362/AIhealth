const translations = {

hi:{
title:"एआई स्वास्थ्य सहायक"
},

pa:{
title:"ਏਆਈ ਸਿਹਤ ਸਹਾਇਕ"
}

};

$("#language").change(function(){

let lang=$(this).val();

$("#title").text(translations[lang].title);

});
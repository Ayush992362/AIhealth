
function contextPath(){
    return window.location.pathname.split("/")[1];
}

function analyzeSymptoms(){

    let symptoms = $("#symptoms").val();
    let age = $("#age").val();

    $.post("/" + contextPath() + "/SymptomServlet",
    {
        symptoms:symptoms,
        age:age
    },
    function(data){
        $("#result").html(data);
    });

}

function askBot(){

    let question = $("#question").val();
    
    if (!question || question.trim() === "") {
        $("#chatResponse").html("<p style='color:red;'>Please enter a question!</p>");
        return;
    }

    // Show loading message
    $("#chatResponse").html("<p style='color:gray;'>Thinking...</p>");

    $.ajax({
        url: "ChatbotServlet",  // Simplified - uses relative path
        type: "POST",
        data: { question: question },
        success: function(data){
            $("#chatResponse").html(data);
        },
        error: function(xhr, status, error){
            $("#chatResponse").html("<p style='color:red;'>Error: " + xhr.status + " - " + error + "<br>Servlet may not be running or URL is incorrect.</p>");
            console.error("Full error:", xhr.responseText);
        }
    });

}

function uploadImage(){

    let file = $("#imageFile")[0].files[0];
    
    if (!file) {
        $("#imageResult").html("<p style='color:red;'>Please select an image file first!</p>");
        return;
    }
    
    // Show loading
    $("#imageResult").html("<p style='color:gray;'>Analyzing image...</p>");
    
    let formData = new FormData();
    formData.append("image", file);

    $.ajax({
        url: "ImageServlet",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(data){
            $("#imageResult").html(data);
        },
        error: function(xhr, status, error){
            $("#imageResult").html("<p style='color:red;'>Error: Unable to process image. Make sure the server is running.</p>");
            console.error("Error:", error);
        }
    });

}
<!DOCTYPE html>
<html>
<head>

<title>Health Chatbot</title>

<link rel="stylesheet" href="css/style.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="js/app.js"></script>

</head>

<body class="container">

<h2>Health Chatbot</h2>

<input type="text"
id="question"
placeholder="Ask a health question"
class="form-control">

<button onclick="askBot()"
class="btn btn-info mt-3">
Ask
</button>

<div id="chatResponse" class="result-box"></div>

</body>
</html>
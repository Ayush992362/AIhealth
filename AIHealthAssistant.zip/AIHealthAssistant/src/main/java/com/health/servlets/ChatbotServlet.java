package com.health.servlets;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/ChatbotServlet")
public class ChatbotServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
                          throws ServletException, IOException {

        String question = request.getParameter("question");
        
        if (question == null || question.trim().isEmpty()) {
            response.setContentType("text/plain");
            response.getWriter().write("Please enter a question.");
            return;
        }

        String questionLower = question.toLowerCase();
        String answer;

        if(questionLower.contains("fever"))
            answer = "Drink fluids and take rest.";

        else if(questionLower.contains("headache"))
            answer = "Take rest and stay hydrated.";

        else
            answer = "Please consult a doctor.";

        response.setContentType("text/plain");
        response.getWriter().write(answer);
    }
}
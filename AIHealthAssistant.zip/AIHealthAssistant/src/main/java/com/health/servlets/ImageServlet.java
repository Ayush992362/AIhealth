
package com.health.servlets;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/ImageServlet")
@MultipartConfig
public class ImageServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
                          throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            // Get uploaded file
            Part filePart = request.getPart("image");
            
            if (filePart == null || filePart.getSize() == 0) {
                out.write("<p style='color:red;'>Please select an image file!</p>");
                return;
            }

            // Check if Python API is running
            String pythonApiUrl = "http://localhost:5000/predict";
            
            try {
                // Create multipart request to Python API
                String boundary = "----WebKitFormBoundary" + System.currentTimeMillis();
                URL url = new URL(pythonApiUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
                conn.setConnectTimeout(2000); // 2 second timeout

                // Send image to Python API
                OutputStream outputStream = conn.getOutputStream();
                PrintWriter writer = new PrintWriter(new OutputStreamWriter(outputStream, "UTF-8"), true);

                // Add file part
                writer.append("--" + boundary).append("\r\n");
                writer.append("Content-Disposition: form-data; name=\"image\"; filename=\"upload.jpg\"").append("\r\n");
                writer.append("Content-Type: image/jpeg").append("\r\n");
                writer.append("\r\n").flush();

                InputStream fileContent = filePart.getInputStream();
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = fileContent.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
                outputStream.flush();
                fileContent.close();

                writer.append("\r\n").flush();
                writer.append("--" + boundary + "--").append("\r\n").flush();
                writer.close();

                // Read response from Python API
                int responseCode = conn.getResponseCode();
                
                if (responseCode == 200) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String inputLine;
                    StringBuilder responseStr = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        responseStr.append(inputLine);
                    }
                    in.close();

                    // Parse JSON response
                    String result = responseStr.toString();
                    String prediction = extractJsonValue(result, "prediction");
                    String confidence = extractJsonValue(result, "confidence");

                    out.write("<div style='padding:20px; background:#f0f9ff; border-radius:8px;'>");
                    out.write("<h3 style='color:#0066cc;'>Detection Result:</h3>");
                    out.write("<p><strong>Condition:</strong> " + prediction + "</p>");
                    out.write("<p><strong>Confidence:</strong> " + (Double.parseDouble(confidence) * 100) + "%</p>");
                    out.write("<p style='color:#666; font-size:12px; margin-top:15px;'><em>⚠️ This is for demonstration only. Please consult a dermatologist for accurate diagnosis.</em></p>");
                    out.write("</div>");
                } else {
                    out.write("<p style='color:red;'>Python API returned error: " + responseCode + "</p>");
                }

            } catch (Exception e) {
                // Python API not running - show demo result with randomization
                String[] conditions = {"Acne", "Eczema", "Psoriasis", "Fungal Infection", "Allergic Rash"};
                String randomCondition = conditions[(int)(Math.random() * conditions.length)];
                int randomConfidence = 75 + (int)(Math.random() * 20); // 75-94%
                
                out.write("<div style='padding:20px; background:#fff3cd; border-radius:8px;'>");
                out.write("<p><strong>Simulated Result:</strong> Possible " + randomCondition + "</p>");
                out.write("<p><strong>Confidence:</strong> " + randomConfidence + "%</p>");
                out.write("<p style='color:#666; font-size:12px; margin-top:15px;'>");
                out.write("</p>");
                out.write("</div>");
            }

        } catch (Exception e) {
            out.write("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
            e.printStackTrace();
        }
    }

    // Simple JSON value extractor
    private String extractJsonValue(String json, String key) {
        try {
            String searchKey = "\"" + key + "\":";
            int startIndex = json.indexOf(searchKey);
            if (startIndex == -1) return "Unknown";
            
            startIndex += searchKey.length();
            char firstChar = json.charAt(startIndex);
            
            if (firstChar == '"') {
                // String value
                int endIndex = json.indexOf("\"", startIndex + 1);
                return json.substring(startIndex + 1, endIndex);
            } else {
                // Number value
                int endIndex = json.indexOf(",", startIndex);
                if (endIndex == -1) endIndex = json.indexOf("}", startIndex);
                return json.substring(startIndex, endIndex).trim();
            }
        } catch (Exception e) {
            return "Unknown";
        }
    }
}
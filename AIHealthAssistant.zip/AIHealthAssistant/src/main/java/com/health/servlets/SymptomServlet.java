package com.health.servlets;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;


public class SymptomServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
                          throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        
        String symptoms = request.getParameter("symptoms");
        String age = request.getParameter("age");
        
        if (symptoms == null || symptoms.trim().isEmpty()) {
            response.getWriter().write("<p style='color:red;'>Please describe your symptoms.</p>");
            return;
        }
        
        // Analyze symptoms directly
        String result = analyzeSymptoms(symptoms);
        response.getWriter().write(result);
    }
    
    // Analysis logic inside the servlet
    private String analyzeSymptoms(String symptoms) {
        symptoms = symptoms.toLowerCase();

        // Emergency symptoms
        if(symptoms.contains("chest pain") || 
           symptoms.contains("difficulty breathing") ||
           symptoms.contains("severe bleeding") ||
           symptoms.contains("unconscious")) {
            return "⚠️ EMERGENCY! Seek immediate medical attention.";
        }

        // Respiratory symptoms
        if(symptoms.contains("fever") && symptoms.contains("cough")) {
            if(symptoms.contains("difficulty") || symptoms.contains("shortness")) {
                return "Possible: Respiratory Infection (75%)";
            }
            return "Possible: Common Flu (70%)";
        }
        
        if(symptoms.contains("cough") && symptoms.contains("sore throat")) {
            return "Possible: Upper Respiratory Infection (65%)";
        }

        // Fever alone
        if(symptoms.contains("fever")) {
            return "Possible: Viral Infection (60%)";
        }

        // Headache variations
        if(symptoms.contains("headache")) {
            if(symptoms.contains("severe") || symptoms.contains("worst")) {
                return "Possible: Severe Migraine (70%)";
            }
            return "Possible: Tension Headache (65%)";
        }
        
        // Digestive issues
        if(symptoms.contains("nausea") || symptoms.contains("vomiting") || symptoms.contains("stomach")) {
            return "Possible: Gastroenteritis (60%)";
        }
        
        // Fatigue/Tiredness
        if(symptoms.contains("tired") || symptoms.contains("fatigue") || symptoms.contains("weakness")) {
            return "Possible: General Fatigue (55%)";
        }

        // Default response
        return "Possible: Minor Ailment (50%). Consult a doctor if symptoms persist.";
    }
}
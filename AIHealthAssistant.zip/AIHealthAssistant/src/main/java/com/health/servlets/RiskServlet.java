package com.health.servlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.health.utils.RiskCalculator;

public class RiskServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
                          throws ServletException, IOException {

        int age = Integer.parseInt(request.getParameter("age"));
        String symptoms = request.getParameter("symptoms");

        String risk = RiskCalculator.calculate(age, symptoms);

        response.getWriter().print("Risk Level: " + risk);
    }
}
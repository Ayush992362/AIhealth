package com.health.utils;

public class RiskCalculator {

public static String calculate(int age,String symptoms){

int score=0;

if(age>60) score+=2;

if(symptoms.contains("fever")) score+=1;

if(symptoms.contains("breathing")) score+=3;

if(score<=2) return "Low Risk";

if(score<=4) return "Medium Risk";

return "High Risk";

}

}